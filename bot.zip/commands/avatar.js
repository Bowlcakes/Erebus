module.exports = {
  name: 'avatar',
  description: 'sends users avatar',
  execute(message, args){

    

  }
}